import { combineReducers } from 'redux';
import searchMusic from './searchMusic';

export default combineReducers({
	searchMusic
})